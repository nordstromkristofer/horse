import React from "react";
import Create from "./Edit/Create";
import ProductList2 from "./ProductList2";

const Backoffice = () => {
  return (
    <div>
      <Create />
      <ProductList2 />
    </div>
  );
};

export default Backoffice;
