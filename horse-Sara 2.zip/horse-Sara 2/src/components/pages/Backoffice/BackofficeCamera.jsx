import React from "react";

const BackofficeCamera = () => {
  return <div>BackofficeCamera</div>;
};

export default BackofficeCamera;
