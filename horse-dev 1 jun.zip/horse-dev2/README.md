# product-list
A product-list in React with a SQLite/Node.js-based backend
